証跡台帳ジェネレーター - オフライン利用セットアップ
======================================================

【なぜこの手順が必要か】
このツールはExcelファイルを作るために「ExcelJS」というライブラリを使用しています。
これまでは起動のたびにインターネット経由でこのライブラリを読み込んでいましたが、
セキュリティ上、外部通信をなくしたいというご要望に対応するため、
ライブラリ本体をお使いのPCに保存し、完全ローカルで動かす方式に変更しました。

ライブラリファイル自体はこちらのツール上では自動生成できない（サイズが大きいため）
ので、以下の手順で「最初の1回だけ」手動で用意してください。
一度用意すれば、それ以降は一切インターネット接続なしで動作します。
（Google Fontsの読み込みは既に廃止済みで、その分は追加作業不要です）

【手順】
1. 信頼できる入手元から exceljs.min.js をダウンロードする
   以下のいずれかから入手してください（社内で許可されたものをご利用ください）。

   ・cdnjs（Cloudflare運営）:
     https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.4.0/exceljs.min.js

   ・npm公式レジストリ経由（jsDelivr）:
     https://cdn.jsdelivr.net/npm/exceljs@4.4.0/dist/exceljs.min.js

   ・npmパッケージから直接取得する場合（Node.js環境があれば）:
     npm install exceljs@4.4.0
     → node_modules/exceljs/dist/exceljs.min.js をコピーして使用

2. ダウンロードした exceljs.min.js を、
   test-evidence-excel-generator.html と「同じフォルダ」に置く

3. ファイル名が exceljs.min.js になっていることを確認する
   （違う名前だとツールが読み込めません）

4. test-evidence-excel-generator.html をブラウザで開いて動作確認する
   「Excelを生成してダウンロード」が正常に動けば設定完了です

【フォルダ構成イメージ】
  お使いのフォルダ/
  ├── test-evidence-excel-generator.html
  └── exceljs.min.js   ← ここに配置

【セキュリティ上のポイント】
- 一度 exceljs.min.js を配置すれば、以降このツールは一切外部通信を行いません
  （画像処理・Excel生成はすべてブラウザ内で完結します）
- ダウンロードしたファイルが改変されていないか気になる場合は、
  社内のセキュリティ担当・情報システム部門にご確認の上、
  承認されたミラーやリポジトリから取得することをおすすめします
- 社内に社内ミラー（Nexus, Artifactory等）がある場合は、そちらから
  exceljs@4.4.0 を取得するのがより安全です
